AI that is typically built using foundation models and has capabilities that earlier AI did not have, such as the ability to generate content. Foundation models (FM) can also be used for non-generative purposes (for example, classifying user sentiment as negative or positive based on call transcripts) while offering significant improvement over earlier models.

#AI #definition
